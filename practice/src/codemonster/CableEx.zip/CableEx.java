package codemonster;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;



public class CableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File f = new File("input.txt");
		try {
			Scanner sc = new Scanner(f);
			FileWriter fw;
			try {
				fw = new FileWriter("result.txt");
				PrintWriter pw = new PrintWriter(fw);
				
				long C = sc.nextInt();
				for(long i=0;i<C;i++){
					Cable com = new  Cable();
					com.input(sc);
					com.fillAllGraph();
					int ans = com.solve(sc);
					pw.println(ans);
				}
				pw.close();
				fw.close();
				sc.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}



class Cable{
	int[][] graph; //��忡�� ���� ������ �ִ� �뿪��
	int N,M;
	Queue<int[]> save = new LinkedList<int[]>();  //graph���� �ٲ� �κ��� �����Ѵ�.
	
	int min(int a,int b){return a>b ?b:a;}
	int max(int a,int b){return a<b ?b:a;}
	
	void input(Scanner sc){
		N = sc.nextInt();
		M = sc.nextInt();
		
		graph = new int[N+1][N+1];
		
		for(int i=0;i<M;i++){
			int a = sc.nextInt();
			int b = sc.nextInt();
			int v = sc.nextInt();
			
			graph[a][b] = v;
			graph[b][a] = v;
			
			putToSave(a,b);
		}
	}
	
	void fillGraphBy(int a, int b){  //node a1�� a2�� ������ ����� �����ϴ� ��� ����� Ž���Ͽ� graph�� ä���
		for(int to=0;to<N;to++){
			if(to==a || to == b) continue;
			
			int temp;
			temp = min(graph[a][b],graph[b][to]) ; // a~to������ v;
			if(temp > graph[a][to]){
				graph[a][to] = temp;  graph[to][a] = temp;
				putToSave(a,b);
				
			}
			
			temp = min(graph[b][a],graph[a][to]) ; // b~to������ v;
			if(temp > graph[b][to]){
				graph[b][to] = temp;  graph[to][b] = temp;
				putToSave(a,b);
			}
		}
	}
	
	void putToSave(int a, int b){
		int[] temp;
		if(a < b)	temp = new int[]{a,b};
		else temp = new int[]{b,a};
	
		if(!save.contains(temp)) save.add(temp);
	}
	
	void fillAllGraph(){
		while(!save.isEmpty()){
			int a = save.peek()[0];
			int b = save.peek()[1];
			save.remove();
			
			fillGraphBy(a,b);
		}	
	}
	
	int solve(Scanner sc){
		int Q = sc.nextInt();
		int sum =0;
		
		
		for(int i=0;i<Q;i++){
			int a = sc.nextInt();
			int b = sc.nextInt();
			
			sum += graph[a][b];
		}
		
		return sum;
	}
}